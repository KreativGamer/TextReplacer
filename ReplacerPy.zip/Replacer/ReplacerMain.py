import tkinter as tk
import webbrowser



webbrowser.open("user.txt")


open('user.txt', 'w').close()
OptionList = [
"",
"Replace",
"ADD",
"Remove"


] 


app = tk.Tk()

app.geometry('900x400')
def say_hello():
    if format(variable2.get()) == "In front of the Line":
        usa = entry_1.get()
        newf=""
        with open('user.txt','r') as f:
            for line in f:
                newf+=usa+" "+line.strip()+"\n"

            f.close()
        with open('user.txt','w') as f:
            f.write(newf)
        f.close()
        webbrowser.open("user.txt")

        
    if format(variable2.get()) == "At the end of the Line":
        usa = entry_1.get()
        newf=""
        with open('user.txt','r') as f:
            for line in f:
                newf+=line.strip()+" "+usa+"\n"

            f.close()
        with open('user.txt','w') as f:
            f.write(newf)
        f.close()
        webbrowser.open("user.txt")

def say_hello1():
    re = entry_2.get()
    inse = entry_3.get()
    newf=""
    with open('user.txt','r') as f:
        for line in f:
            newf+=line.strip()+"\n"

            newf1=(newf.replace(re, inse))
        f.close()
    with open('user.txt','w') as f:
        f.write(newf1)
    f.close()
    webbrowser.open("user.txt")


def say_hello2():
    re1 = entry_4.get()
    newf=""
    with open('user.txt','r') as f:
        for line in f:
            newf+=line.strip()+"\n"

            newf1=(newf.replace(re1, ""))
        f.close()
    with open('user.txt','w') as f:
        f.write(newf1)
    f.close()
    webbrowser.open("user.txt")

variable = tk.StringVar(app)
variable.set(OptionList[0])

opt = tk.OptionMenu(app, variable, *OptionList)
opt.config(width=90, font=('Helvetica', 12))
opt.grid(row=4, column=0)

f = tk.Label(app, text="Instructions:",  font=('Helvetica', 12), fg='red', background='white')
f.grid(row=0, column=0)

fg = tk.Label(app, text="Copy your text in the textfile that was open and then save it.",  font=('Helvetica', 12), fg='red', background='white')
fg.grid(row=1, column=0)

fg1 = tk.Label(app, text="Now you can close the Window and choose your option. When your are ready hit the submit button and there are the results",  font=('Helvetica', 12), fg='red', background='white')
fg1.grid(row=2, column=0)

fg2 = tk.Label(app, text="When your are ready hit the submit button and there are the results",  font=('Helvetica', 12), fg='red', background='white')
fg2.grid(row=3, column=0)

OptionList2 = [
"In front of the Line",
"At the end of the Line"
]
variable2 = tk.StringVar(app)
variable2.set(OptionList[0])
opt2 = tk.OptionMenu(app, variable2, *OptionList2)
opt2.config(width=90, font=('Helvetica', 12))

app.iconbitmap('Icon.ico')
app.configure(background='white')
app.title('TextFormater')



OptionList3 = [
"In front of the Line",
"At the end of the Line"
]
variable3 = tk.StringVar(app)
variable3.set(OptionList[0])
opt3 = tk.OptionMenu(app, variable3, *OptionList3)
opt3.config(width=90, font=('Helvetica', 12))

entry_1 = tk.Entry(app, font="Times 32", background='light grey')
entry_2 = tk.Entry(app, font="Times 32", background='light grey')
entry_3 = tk.Entry(app, font="Times 32", background='light grey')
entry_4 = tk.Entry(app, font="Times 32", background='light grey')



button_1=tk.Button(app, text="Submit", command=say_hello1, font="Times 32")
button_2=tk.Button(app, text="Submit", command=say_hello, font="Times 32")
button_3=tk.Button(app, text="Submit", command=say_hello2, font="Times 32")

def callback(*args):
    if format(variable.get()) == "Replace":



        button_1.grid(row=7, column=0)
        entry_2.grid(row=5, column=0)
        entry_3.grid(row=6, column=0)
        opt2.grid_remove()
        button_2.grid_remove()
        entry_1.grid_remove()
        entry_4.grid_remove()
        button_3.grid_remove()


    if format(variable.get()) == "ADD":

        opt2.grid(row=5, column=0)

        button_2.grid(row=7, column=0)

        entry_1.grid(row=6, column=0)
        entry_2.grid_remove()
        entry_3.grid_remove()
        button_1.grid_remove()
        entry_4.grid_remove()
        button_3.grid_remove()


    if format(variable.get()) == "Remove":
        button_3.grid(row=6, column=0)
        entry_4.grid(row=5, column=0)
        opt2.grid_remove()
        button_2.grid_remove()
        entry_1.grid_remove()
        entry_2.grid_remove()
        entry_3.grid_remove()
        button_1.grid_remove()





variable.trace("w", callback)

app.mainloop()
